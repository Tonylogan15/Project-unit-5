# Project 5 - Choose Your Own Adventure API

**Name:** Your Name  
**App:** API Adventure – PokéAPI

## 🎯 Goals
- Choose an API and read its docs
- Parse JSON responses
- Display multiple fields from an API

## ✅ Required Features Implemented
- [x] Uses CodePath `AsyncHttpClient` to make an API request (PokéAPI: `https://pokeapi.co/api/v2/pokemon/{id}`)
- [x] Displays at least three data points per entry:
  - [x] Image (official artwork / sprite via Glide)
  - [x] Name
  - [x] Type(s), Height, and Weight
- [x] Button fetches a new random Pokémon and updates the UI

## 🖼 Walkthrough GIF / Video
Add a link to your GIF or Loom video here.

## 🧰 Technical Notes
- Kotlin + ViewBinding + ConstraintLayout
- `AsyncHttpClient` for network calls
- `Glide` for image loading
- Internet permission in `AndroidManifest.xml`

## 📦 How to Run
1. Open Android Studio.
2. **File → Open…** and select this project folder.
3. Let Gradle sync; click **Run ▶** on an emulator/device.
4. Press **Get Random Pokémon** to fetch a new entry.

## 🧪 Stretch Ideas
- Search by name/ID via EditText
- Show base stats in a list
- Cache last result across rotations
- Share card as image

## 🔄 Swap API (Optional)
Want NASA or Marvel instead? Replace the URL and parsing logic in `MainActivity.kt` accordingly.
- NASA (use `DEMO_KEY` for many endpoints): https://api.nasa.gov/
- Marvel (auth example in assignment; requires keys): https://developer.marvel.com/

## 📚 Resources
- CodePath AsyncHttpClient
- Glide
- ConstraintLayout
- PokéAPI Docs: https://pokeapi.co/