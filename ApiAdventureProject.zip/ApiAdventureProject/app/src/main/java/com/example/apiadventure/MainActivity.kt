package com.example.apiadventure

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import com.example.apiadventure.databinding.ActivityMainBinding
import okhttp3.Headers
import org.json.JSONObject
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val client = AsyncHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnFetch.setOnClickListener {
            fetchRandomPokemon()
        }

        // Fetch one on launch
        fetchRandomPokemon()
    }

    private fun fetchRandomPokemon() {
        binding.tvError.text = ""
        val id = Random.nextInt(1, 898) // Gen 1-8 range known by PokeAPI
        val url = "https://pokeapi.co/api/v2/pokemon/$id"

        client.get(url, object : JsonHttpResponseHandler() {
            override fun onSuccess(statusCode: Int, headers: Headers?, json: JSON) {
                val obj: JSONObject = json.jsonObject
                val name = obj.getString("name")
                val height = obj.getInt("height")
                val weight = obj.getInt("weight")

                // types is an array
                val typesArray = obj.getJSONArray("types")
                val types = (0 until typesArray.length()).joinToString(", ") { idx ->
                    typesArray.getJSONObject(idx).getJSONObject("type").getString("name")
                }

                // sprites → other → official-artwork → front_default (fallback to front_default)
                val sprites = obj.getJSONObject("sprites")
                val other = sprites.optJSONObject("other")
                val official = other?.optJSONObject("official-artwork")
                val artUrl = official?.optString("front_default")
                    ?: sprites.optString("front_default")

                binding.tvName.text = name.replaceFirstChar { it.uppercase() }
                binding.tvTypes.text = "Type(s): $types"
                binding.tvStats.text = "Height: $height | Weight: $weight"

                if (artUrl.isNullOrBlank()) {
                    binding.ivSprite.setImageDrawable(null)
                } else {
                    Glide.with(this@MainActivity)
                        .load(artUrl)
                        .into(binding.ivSprite)
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                response: String?,
                throwable: Throwable?
            ) {
                binding.tvError.text = "Failed: $statusCode"
            }
        })
    }
}